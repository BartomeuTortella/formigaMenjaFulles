/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formigamenjafulles;

/**
 *
 * @author bartomeu
 */

//classe Buit que exten de la classe Figura
public class Buit extends Figura {

    public Buit() {
        //constructor que simplement passa a la classe figura la imatge de buit
        super("img/nada.png");
    }

}
